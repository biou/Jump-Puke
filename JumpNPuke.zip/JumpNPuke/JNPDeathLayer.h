//
//  JNPDeath.h
//  JumpNPuke
//
//  Created by Alain Vagner on 28/01/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "JNPAudioManager.h"
#import "JNPMenuScene.h"

@interface JNPDeathLayer : CCLayer {
    
}

// returns a CCScene that contains the JNPDeath layer as the only child
+(CCScene *) scene;

@end
